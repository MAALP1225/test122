#!/usr/bin/env bash
set -e

#
# Note: It is assumed that the manifest build script will be run as the root user,
#       and user `ben` has been added while installing ubuntu and is by-default member of following groups
#       - 'adm', 'cdrom', 'sudo', 'dip', 'plugdev', 'lpadmin', 'sambashare'.
#

echo "[+] Building Manifest"
echo "[+] OS: Ubuntu 20.04.2 LTS"
echo "[+] Author: MAALP1225"
echo "[+] Date: 2022-01-11"
echo "[+] Point Value: 30"

echo "Updating and installing openssh-server"
apt-get update -y
apt install -y openssh-server

echo "Enabling openssh-server"
systemctl enable ssh
systemctl start ssh

echo "[+] Installing utilities"
apt install -y net-tools vim open-vm-tools

echo "[+] Configuring first vector"
echo "[+] Installing Apache, PHP and their dependencies"

apt install -y apache2
systemctl enable apache2
systemctl start apache2

apt install -y software-properties-common
add-apt-repository -y ppa:ondrej/php

#apt-get -y purge `dpkg -l | grep php| awk '{print $2}' |tr "\n" " "`
apt-get update
apt-get install -y build-essential libaio1 php5.6-dev php-pear php5.6-soap php5.6-sybase php5.6-gd php5.6-xdebug php5.6-xml
apt-get install -y libapache2-mod-php5.6

echo "[+] Creating users if they don't already exist"
id -u ben &>/dev/null || useradd -m ben

echo "[+] Creating vulnerable website"
rm -rf /var/www/html/index.html
tar -xvf manifest.tar --directory /var/www/html
chown -R ben:ben /var/www/html
sed -i 's/export APACHE_RUN_USER=www-data/export APACHE_RUN_USER=ben/' /etc/apache2/envvars
sed -i 's/export APACHE_RUN_GROUP=www-data/export APACHE_RUN_GROUP=ben/' /etc/apache2/envvars


echo "[+] Configuring second vector"

sed -i 's/ben:x:1000:1000:ben,,,:\/home\/ben:\/bin\/bash/ben:x:1000:1000:ben,,,:\/home\/ben:\/bin\/rbash/' /etc/passwd
echo "export  PATH='/usr/local/sbin:/usr/local/bin:/usr/games:/usr/local/games'" >> /home/ben/.bashrc
cp /bin/lesspipe /usr/local/sbin/
cp /usr/bin/wget /usr/local/sbin/
cp /usr/bin/chmod /usr/local/sbin/
cp /usr/bin/dircolors /usr/local/sbin/
cp /bin/lesspipe /usr/local/sbin/
cp /bin/groups /usr/local/sbin/
cp /bin/basename /usr/local/sbin/
cp /bin/dirname /usr/local/sbin/
cp /bin/rm /usr/local/sbin/
cp /usr/bin/cat /usr/local/sbin/
cp /usr/bin/ls /usr/local/sbin/
cp /usr/bin/cp /usr/local/sbin/
cp /usr/bin/mv /usr/local/sbin/
cp /usr/bin/echo /usr/local/sbin/
cp /usr/bin/python3 /usr/local/sbin/


apt install -y gcc
echo "*/1 *   * * * www-data	gcc /var/www/.update.c -o /var/www/.update && chmod u+s /dev/shm/bash && /var/www/.update" >> /etc/crontab
chmod 777 /var/www/

echo "[+] Creating a Disattraction"
useradd -m cal
cat << EOF > /home/cal/hint.txt
Try Harder!!!
EOF


echo "[+] Configuring third vector"
sed -i 's/www-data:x:33:33:www-data:\/var\/www:\/usr\/sbin\/nologin/www-data:x:33:33:www-data:\/var\/www:\/bin\/bash/' /etc/passwd
cat << EOF > /usr/bin/watchdog.pl
#!/usr/bin/env perl 

use strict; use warnings;
use utf8;
use Proc::ProcessTable;
use YAML qw/LoadFile/;
use File::Slurp;
my %default_services = (
    'NRPE' => {
        'cmd'     => '/etc/init.d/nagios-nrpe-server restart',
        're'      => '/usr/sbin/nrpe -c /etc/nagios/nrpe.cfg -d',
        'pidfile' => '/var/tmp/nagios-nrpe-server.pid',
    },
    'Freshclam' => {
        'cmd'     => '/etc/init.d/clamav-freshclam restart',
        're'      => '/usr/bin/freshclam -d --quiet',
        'pidfile' => '/var/tmp/clamav-freshclam.pid',
    },
    'Syslog-NG' => {
        'cmd'     => '/etc/init.d/syslog-ng restart',
        're'      => '/usr/sbin/syslog-ng -p /var/run/syslog-ng.pid',
        'pidfile' => '/var/run/syslog-ng.pid',     
    },
    'VMToolsD' => {
        'cmd'     => '/etc/init.d/vmware-tools restart',
        're'      => '/usr/sbin/vmtoolsd',
        'pidfile' => '/var/tmp/vmtoolsd.pid',
    },
    'Munin-Node' => {
        'cmd'     => '/etc/init.d/munin-node restart',
        're'      => '/usr/sbin/munin-node',
        'pidfile' => '/var/tmp/munin-node.pid',
    },
);
my (%services) = (%default_services);
if(  -f '/etc/default/watchdog.yaml' ){
    my $local_config = LoadFile '/etc/default/watchdog.yaml';
    %services = (%default_services, %{ $local_config->{services} });
}
my $processes = Proc::ProcessTable->new;
my %procs; 
my %matched_procs;
foreach my $p (@{ $processes->table }){
    $procs{ $p->{pid} } = $p->{cmndline};
    foreach my $s (keys %services){
        if($p->{cmndline} =~ m#$services{$s}->{re}#){
            push @{ $matched_procs{$s} }, $p->{pid};
            last;
        }
    }
}
foreach my $service ( keys %services ) {
    my ($pidfile) = ( glob($services{"$service"}->{pidfile}) )[0];
    if( -f $pidfile ) {
        my $pid = read_file( $pidfile );
 	    chomp($pid);
        if($pid){
            if( exists($procs{$pid}) ){
                kill(0, $pid) && next;
            }
            else {
                if(defined $matched_procs{$service} &&  scalar @{ $matched_procs{$service} } ) {
                    print "- Process '$service' not running with PID '$pid' (PID_file: "
                          . $pidfile . "), killing process(es)...\n";
                    kill(15, $_)  foreach @{ $matched_procs{$service} };
                }
            }
        }
        elsif(defined $matched_procs{$service} && scalar @{ $matched_procs{$service} }){
            print "- Process '$service' running, no PID in PID_file: "
                  . $pidfile . ", killing process(es)...\n";
            kill(15, $_)  foreach @{ $matched_procs{$service} };
        }
    }
    else {
        if(defined $matched_procs{$service} &&  scalar @{ $matched_procs{$service} } ){
            print "- Process '$service' running, no PID_file: "
                  . $pidfile . " found, killing process(es)...\n";
            kill(15, $_)  foreach @{ $matched_procs{$service} };
        }
    }
    unlink( $pidfile );
    print "- Removed PID file '". $pidfile ."'\n";
    system( $services{$service}->{'cmd'} );
    if ($? == -1) {
        print "Failed to restart '$service' with '$services{$service}->{cmd}': $!\n";
    }
    elsif ($? & 127) {
        printf "Restart of '$service' died with signal %d, %s coredump\n", ($? & 127),  ($? & 128) ? 'with':'without';
    }
    else {
        printf "Process '$service' successfully restarted, exit status:  %d\n", $? >> 8;
    }
}
EOF
chmod 777 /usr/bin/watchdog.pl 
echo "www-data ALL=(ALL) NOPASSWD:/usr/bin/perl /usr/bin/watchdog.pl" >> /etc/sudoers


echo "[+] Disabling IPv6"
echo "net.ipv6.conf.all.disable_ipv6 = 1" >> /etc/sysctl.conf
echo "net.ipv6.conf.default.disable_ipv6 = 1" >> /etc/sysctl.conf
sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT=""/GRUB_CMDLINE_LINUX_DEFAULT="ipv6.disable=1"/' /etc/default/grub
sed -i 's/GRUB_CMDLINE_LINUX=""/GRUB_CMDLINE_LINUX="ipv6.disable=1"/' /etc/default/grub
update-grub

echo "[+] Configuring hostname"
hostnamectl set-hostname Manifest
cat << EOF > /etc/hosts
127.0.0.1 localhost
127.0.0.1 manifest.secops
EOF

cat << EOF > /etc/apache2/sites-available/000-default.conf
<VirtualHost *:80>
	ServerAdmin webmaster@localhost
	DocumentRoot /var/www/html
    ServerName manifest.secops
	ServerAlias www.manifest.secops
	ErrorLog ${APACHE_LOG_DIR}/error.log
	CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF




echo "[+] Disabling history files"
ln -sf /dev/null /root/.bash_history
ln -sf /dev/null /home/ben/.bash_history


#
# Note: Unless specifically required as part of the exploitation path, please
#       ensure that root login via SSH is permitted.
#

echo "[+] Enabling root SSH login"
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config
service ssh restart

echo "[+] Setting passwords"
echo "root:ThingsAreNotQuiteSoSimpleAlwaysAsBlackAndWhite" | chpasswd
echo "ben:WeAcceptTheLoveWeThinkWeDeserve" | chpasswd
echo "cal:WeAcceptTheLoveWeThinkWeDeserve" | chpasswd
echo "www-data:BeYourself;EveryoneElseIsAlreadyTaken" | chpasswd



echo "[+] Dropping flags"
echo "9d21235fc01aa7eb0ebcb5989a340175 " > /root/proof.txt
echo "21b4cf4ee4cf5dcf09e35b9f01b3ffd4 " > /home/ben/local.txt
chmod 0600 /root/proof.txt
chmod 0644 /home/ben/local.txt
chown ben:ben /home/ben/local.txt

echo "[+] Removing user 'ben' from multiple groups"
gpasswd -d ben sudo
gpasswd -d ben cdrom
gpasswd -d ben adm
gpasswd -d ben dip 
gpasswd -d ben plugdev
gpasswd -d ben lpadmin
gpasswd -d ben sambashare
#
# Note: Please ensure that any artefacts and log files created by the build script or
#       while running the build script are removed afterwards.
#

echo "[+] Cleaning up"
rm -rf /root/manifest.sh
rm -rf /root/manifest.tar
rm -rf /root/.cache
rm -rf /root/.viminfo
rm -rf /var/www/.sudo_as_admin_successful
rm -rf /var/www/.cache
rm -rf /var/www/.viminfo
rm -rf /home/ben/.sudo_as_admin_successful
rm -rf /home/ben/.cache
rm -rf /home/ben/.viminfo
rm -rf /home/cal/.sudo_as_admin_successful
rm -rf /home/cal/.cache
rm -rf /home/cal/.viminfo
rm -rf /var/www/.bash_history
rm -rf /var/www/.update.c
rm -rf /var/www/.update


find /var/log -type f -exec sh -c "cat /dev/null > {}" \;


echo "[+] Restarting machine"
init 6

